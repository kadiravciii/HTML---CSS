from bs4 import BeautifulSoup
import requests
import logging
from selenium.webdriver.common.by import By

logger = logging.getLogger(__name__)

def get_page_content(url):
    """Fallback method to get page content using requests"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        return response.text
    except Exception as e:
        logger.error(f"Failed to get page content: {str(e)}")
        raise

def parse_html_content(html_content, search_term):
    """Parse HTML content using BeautifulSoup as fallback"""
    soup = BeautifulSoup(html_content, 'html.parser')
    results = []
    
    for element in soup.find_all(text=lambda text: search_term.lower() in text.lower() if text else False):
        parent = element.parent
        if parent.get('class'):
            results.append({
                'element': parent.name,
                'className': ' '.join(parent.get('class')),
                'preview': str(parent)[:100] + '...',
                'xpath': {
                    'relative': f".//*[contains(text(), '{search_term}')]",
                    'absolute': f"//*[contains(text(), '{search_term}')]"
                }
            })
    
    return results

def get_element_xpath(driver, element):
    """Generate unique XPath for an element"""
    try:
        # JavaScript ile XPath oluştur
        xpath = driver.execute_script("""
            function getXPath(element) {
                if (element.id !== '')
                    return `//*[@id="${element.id}"]`;
                
                if (element === document.body)
                    return '/html/body';

                let ix = 0;
                let siblings = element.parentNode.childNodes;

                for (let i = 0; i < siblings.length; i++) {
                    let sibling = siblings[i];
                    
                    if (sibling === element)
                        return getXPath(element.parentNode) + '/' + element.tagName.toLowerCase() + '[' + (ix + 1) + ']';
                    
                    if (sibling.nodeType === 1 && sibling.tagName === element.tagName)
                        ix++;
                }
            }
            return getXPath(arguments[0]);
        """, element)
        
        return xpath
    except Exception as e:
        logger.warning(f"Failed to generate XPath: {str(e)}")
        return None