from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.chrome.options import Options as ChromeOptions
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.chrome import ChromeDriverManager
from config import Config
import logging

logger = logging.getLogger(__name__)

class BrowserManager:
    @staticmethod
    def create_driver():
        try:
            if Config.BROWSER_TYPE.lower() == 'firefox':
                return BrowserManager._setup_firefox()
            else:
                return BrowserManager._setup_chrome()
        except Exception as e:
            logger.error(f"Failed to create browser driver: {str(e)}")
            raise

    @staticmethod
    def _setup_firefox():
        options = FirefoxOptions()
        if Config.HEADLESS:
            options.add_argument('--headless')
        
        # DevTools DOM ağacını genişletme ayarları
        options.set_preference("devtools.inspector.showAllAnonymousContent", True)
        options.set_preference("devtools.defaultCollapsed", False)
        options.set_preference("devtools.dom.expand-all", True)
        
        service = FirefoxService(GeckoDriverManager().install())
        driver = webdriver.Firefox(service=service, options=options)
        driver.set_page_load_timeout(Config.PAGE_LOAD_TIMEOUT)
        
        # DevTools CDP komutu ile DOM ağacını genişlet
        driver.execute_script("""
            document.querySelectorAll('*').forEach(element => {
                element.setAttribute('expanded', 'true');
            });
        """)
        
        return driver

    @staticmethod
    def _setup_chrome():
        options = ChromeOptions()
        if Config.HEADLESS:
            options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        # Chrome DevTools protokolü ayarları
        options.add_argument('--auto-open-devtools-for-tabs')
        options.add_experimental_option('prefs', {
            'devtools.preferences.expandNodeByDefault': True,
            'devtools.preferences.showAllNodes': True
        })
        
        service = ChromeService(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
        driver.set_page_load_timeout(Config.PAGE_LOAD_TIMEOUT)
        
        # DevTools CDP komutu ile DOM ağacını genişlet
        driver.execute_cdp_cmd('DOM.enable', {})
        driver.execute_cdp_cmd('DOM.getDocument', {'depth': -1, 'pierce': True})
        
        return driver