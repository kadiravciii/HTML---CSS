from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from browser_manager import BrowserManager
from scraper_utils import get_page_content, parse_html_content, get_element_xpath
from config import Config
import logging
import time

logger = logging.getLogger(__name__)

def wait_for_maps_content(driver):
    """Google Maps'in dinamik içeriğinin yüklenmesini bekler"""
    try:
        # Ana içerik konteynerinin yüklenmesini bekle
        WebDriverWait(driver, Config.ELEMENT_TIMEOUT).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'div[role="main"]'))
        )
        
        # Dinamik içeriğin yüklenmesi için bekleme
        time.sleep(2)
        
        # Sayfayı scroll ederek dinamik içeriği tetikle
        driver.execute_script(
            "window.scrollTo(0, document.body.scrollHeight/2);"
            "window.scrollTo(0, 0);"
        )
        
        # Tüm kapalı elementleri aç
        elements = driver.find_elements(By.CSS_SELECTOR, 'div[jsaction*="pane."], div[jsaction*="mouseover"]')
        for element in elements:
            try:
                driver.execute_script("arguments[0].click();", element)
                time.sleep(0.5)
            except:
                continue
                
    except Exception as e:
        logger.warning(f"Maps content loading warning: {str(e)}")

def scrape_with_selenium(url, search_term):
    driver = None
    try:
        driver = BrowserManager.create_driver()
        driver.get(url)
        
        # Google Maps için özel işlem
        if 'google.com/maps' in url:
            wait_for_maps_content(driver)
        else:
            # Normal sayfalar için standart bekleme
            WebDriverWait(driver, Config.ELEMENT_TIMEOUT).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
        
        # İçeriği ara
        elements = driver.find_elements(
            By.XPATH,
            f"//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{search_term.lower()}')]"
        )
        
        results = []
        for element in elements:
            try:
                # Element bilgilerini topla
                class_name = element.get_attribute('class')
                xpath = get_element_xpath(driver, element)
                parent_xpath = get_element_xpath(driver, element.find_element(By.XPATH, ".."))
                
                if class_name:
                    results.append({
                        'element': element.tag_name,
                        'className': class_name,
                        'preview': element.get_attribute('outerHTML')[:100] + '...',
                        'xpath': {
                            'self': xpath,
                            'parent': parent_xpath,
                            'relative': f".//*[contains(text(), '{search_term}')]",
                            'absolute': f"//*[contains(text(), '{search_term}')]"
                        },
                        'attributes': {
                            attr: element.get_attribute(attr)
                            for attr in ['id', 'name', 'role', 'aria-label']
                            if element.get_attribute(attr)
                        }
                    })
            except Exception as e:
                logger.warning(f"Failed to get element details: {str(e)}")
                continue
        
        return results
    
    except Exception as e:
        logger.error(f"Selenium scraping failed: {str(e)}")
        raise
    
    finally:
        if driver:
            driver.quit()

def scrape_website(url, search_term):
    if not url.startswith('http'):
        url = 'https://' + url
        
    logger.info(f'Starting scraping process for: {url}')
    logger.info(f'Search term: {search_term}')
    
    try:
        # Önce Selenium ile dene
        return scrape_with_selenium(url, search_term)
    except Exception as selenium_error:
        logger.warning(f"Selenium scraping failed, trying fallback method: {str(selenium_error)}")
        try:
            # Başarısız olursa requests + BeautifulSoup ile dene
            html_content = get_page_content(url)
            return parse_html_content(html_content, search_term)
        except Exception as fallback_error:
            logger.error(f"Fallback scraping failed: {str(fallback_error)}")
            raise