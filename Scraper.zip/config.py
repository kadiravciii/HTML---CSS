import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    FLASK_PORT = 3000
    BROWSER_TYPE = os.getenv('BROWSER_TYPE', 'chrome')  # firefox veya chrome
    HEADLESS = True
    PAGE_LOAD_TIMEOUT = 30
    ELEMENT_TIMEOUT = 10