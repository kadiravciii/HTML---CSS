import React from 'react';
import WebScraper from './components/WebScraper';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <WebScraper />
    </div>
  );
}

export default App;