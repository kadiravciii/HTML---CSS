import axios from 'axios';
import { ScrapingResult } from '../types';

const API_URL = 'http://localhost:3000/api';

export async function scrapeWebsite(url: string, searchTerm: string): Promise<ScrapingResult[]> {
  try {
    const response = await axios.post(`${API_URL}/scrape`, { url, searchTerm });
    return response.data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}