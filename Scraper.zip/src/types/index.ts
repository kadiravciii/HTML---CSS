export interface ScrapingResult {
  element: string;
  className: string;
  preview: string;
}