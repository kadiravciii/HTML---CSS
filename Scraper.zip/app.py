from flask import Flask, request, jsonify
from flask_cors import CORS
from scraper import scrape_website
from config import Config
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

@app.route('/api/scrape', methods=['POST'])
def scrape():
    try:
        data = request.json
        url = data.get('url')
        search_term = data.get('searchTerm')
        
        if not url or not search_term:
            return jsonify({
                'error': 'URL and search term are required',
                'details': {
                    'url': 'provided' if url else 'missing',
                    'searchTerm': 'provided' if search_term else 'missing'
                }
            }), 400
        
        results = scrape_website(url, search_term)
        return jsonify(results)
        
    except Exception as e:
        logger.error(f"API Error: {str(e)}", exc_info=True)
        return jsonify({
            'error': 'Failed to scrape website',
            'details': str(e),
            'url': request.json.get('url')
        }), 500

if __name__ == '__main__':
    app.run(port=Config.FLASK_PORT)