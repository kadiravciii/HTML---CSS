import * as cheerio from 'cheerio';
import axios from 'axios';

async function scrapeGoogleMaps(url, searchTerm) {
  try {
    console.log('Scraping Google Maps URL:', url);
    
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.google.com/',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0'
      },
      timeout: 30000,
      maxRedirects: 5
    });

    const html = response.data;
    if (!html) {
      throw new Error('No HTML content received from Google Maps');
    }

    console.log('Parsing Google Maps content...');
    const $ = cheerio.load(html);
    const results = [];

    // Google Maps'e özel seçiciler
    const selectors = [
      '[role="main"]',
      '[role="article"]',
      '.section-hero-header-title',
      '.section-result-title',
      '.section-result-content'
    ];

    selectors.forEach(selector => {
      $(selector).each((_, element) => {
        const $el = $(element);
        const text = $el.text();
        
        if (text.toLowerCase().includes(searchTerm.toLowerCase())) {
          results.push({
            element: element.name,
            className: $el.attr('class') || 'no-class',
            preview: $el.toString().slice(0, 100) + '...'
          });
        }
      });
    });

    console.log(`Found ${results.length} matching elements in Google Maps`);
    return results;
  } catch (error) {
    console.error('Google Maps scraping error:', {
      phase: 'scraping',
      error: {
        name: error.name,
        message: error.message,
        stack: error.stack
      },
      url: url,
      responseStatus: error.response?.status,
      responseStatusText: error.response?.statusText
    });
    throw new Error(`Google Maps scraping failed: ${error.message}`);
  }
}

async function scrapeRegularWebsite(url, searchTerm) {
  try {
    console.log('Scraping regular website:', url);
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      },
      timeout: 30000
    });
    
    const html = response.data;
    if (!html) {
      throw new Error('No HTML content received');
    }
    
    const $ = cheerio.load(html);
    const results = [];

    $('*').each((_, element) => {
      const $el = $(element);
      const text = $el.text();
      
      if (text.toLowerCase().includes(searchTerm.toLowerCase())) {
        const className = $el.attr('class');
        if (className) {
          results.push({
            element: element.name,
            className: className,
            preview: $el.toString().slice(0, 100) + '...'
          });
        }
      }
    });

    console.log(`Found ${results.length} matching elements`);
    return results;
  } catch (error) {
    console.error('Regular website scraping error:', {
      error: {
        name: error.name,
        message: error.message
      },
      url: url
    });
    throw error;
  }
}

export async function scrapeWebsite(url, searchTerm) {
  try {
    if (!url.startsWith('http')) {
      url = 'https://' + url;
    }

    console.log('Starting scraping process for:', url);
    console.log('Search term:', searchTerm);

    if (url.includes('google.com/maps') || url.includes('maps.google.com')) {
      return await scrapeGoogleMaps(url, searchTerm);
    }

    return await scrapeRegularWebsite(url, searchTerm);
  } catch (error) {
    console.error('Scraping failed:', {
      url: url,
      searchTerm: searchTerm,
      error: {
        name: error.name,
        message: error.message
      }
    });
    throw error;
  }
}