import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { scrapeWebsite } from './scraper.js';

const app = express();
const port = 3000;

app.use(cors());

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});

app.use(limiter);
app.use(express.json());

app.post('/api/scrape', async (req, res) => {
  try {
    const { url, searchTerm } = req.body;
    
    if (!url || !searchTerm) {
      return res.status(400).json({ 
        error: 'URL and search term are required',
        details: {
          url: url ? 'provided' : 'missing',
          searchTerm: searchTerm ? 'provided' : 'missing'
        }
      });
    }

    const results = await scrapeWebsite(url, searchTerm);
    res.json(results);
  } catch (error) {
    console.error('API Error:', {
      error: error.message,
      stack: error.stack,
      body: req.body
    });
    
    res.status(500).json({ 
      error: 'Failed to scrape website',
      details: error.message,
      url: req.body.url
    });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});